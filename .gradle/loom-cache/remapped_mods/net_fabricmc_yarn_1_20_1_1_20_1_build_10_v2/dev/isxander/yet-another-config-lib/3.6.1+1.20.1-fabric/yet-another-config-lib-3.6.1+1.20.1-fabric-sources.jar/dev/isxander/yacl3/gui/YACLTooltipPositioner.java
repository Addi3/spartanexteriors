package dev.isxander.yacl3.gui;

import org.joml.Vector2i;
import org.joml.Vector2ic;
import dev.isxander.yacl3.api.utils.Dimension;
import java.util.function.Supplier;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.tooltip.TooltipPositioner;
import net.minecraft.util.math.MathHelper;

public class YACLTooltipPositioner implements TooltipPositioner {
    private final Supplier<ScreenRect> buttonDimensions;

    public YACLTooltipPositioner(net.minecraft.client.gui.widget.ClickableWidget widget) {
        this.buttonDimensions = widget::getNavigationFocus;
    }

    public YACLTooltipPositioner(dev.isxander.yacl3.gui.AbstractWidget widget) {
        this.buttonDimensions = () -> {
            var dim = widget.getDimension();
            return new ScreenRect(dim.x(), dim.y(), dim.width(), dim.height());
        };
    }

    public YACLTooltipPositioner(Supplier<ScreenRect> buttonDimensions) {
        this.buttonDimensions = buttonDimensions;
    }

    @Override
    public Vector2ic getPosition(int guiWidth, int guiHeight, int x, int y, int width, int height) {
        ScreenRect buttonDimensions = this.buttonDimensions.get();

        int centerX = buttonDimensions.getLeft() + buttonDimensions.width() / 2;
        int aboveY = buttonDimensions.getTop() - height - 4;
        int belowY = buttonDimensions.getTop() + buttonDimensions.height() + 4;

        int maxBelow = guiHeight - (belowY + height);
        int minAbove = aboveY - height;

        int yResult = aboveY;
        if (minAbove < 8)
            yResult = maxBelow > minAbove ? belowY : aboveY;

        int xResult = MathHelper.clamp(centerX - width / 2, -4, guiWidth - width - 4);

        return new Vector2i(xResult, yResult);
    }
}
