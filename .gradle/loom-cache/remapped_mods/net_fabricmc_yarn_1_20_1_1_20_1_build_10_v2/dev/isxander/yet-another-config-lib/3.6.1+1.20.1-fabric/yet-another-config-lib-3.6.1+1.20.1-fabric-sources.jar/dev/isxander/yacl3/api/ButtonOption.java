package dev.isxander.yacl3.api;

import dev.isxander.yacl3.gui.YACLScreen;
import dev.isxander.yacl3.impl.ButtonOptionImpl;
import org.jetbrains.annotations.NotNull;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.text.Text;

public interface ButtonOption extends Option<BiConsumer<YACLScreen, ButtonOption>> {
    /**
     * Action to be executed upon button press
     */
    BiConsumer<YACLScreen, ButtonOption> action();

    static dev.isxander.yacl3.api.ButtonOption.Builder createBuilder() {
        return new ButtonOptionImpl.BuilderImpl();
    }

    interface Builder {
        /**
         * Sets the name to be used by the option.
         *
         * @see Option#name()
         */
        dev.isxander.yacl3.api.ButtonOption.Builder name(@NotNull Text name);

        /**
         * Sets the button text to be displayed next to the name.
         */
        dev.isxander.yacl3.api.ButtonOption.Builder text(@NotNull Text text);

        dev.isxander.yacl3.api.ButtonOption.Builder description(@NotNull OptionDescription description);

        dev.isxander.yacl3.api.ButtonOption.Builder action(@NotNull BiConsumer<YACLScreen, ButtonOption> action);

        /**
         * Action to be executed upon button press
         *
         * @see ButtonOption#action()
         */
        @Deprecated
        dev.isxander.yacl3.api.ButtonOption.Builder action(@NotNull Consumer<YACLScreen> action);

        /**
         * Sets if the option can be configured
         *
         * @see Option#available()
         */
        dev.isxander.yacl3.api.ButtonOption.Builder available(boolean available);

        ButtonOption build();
    }
}
