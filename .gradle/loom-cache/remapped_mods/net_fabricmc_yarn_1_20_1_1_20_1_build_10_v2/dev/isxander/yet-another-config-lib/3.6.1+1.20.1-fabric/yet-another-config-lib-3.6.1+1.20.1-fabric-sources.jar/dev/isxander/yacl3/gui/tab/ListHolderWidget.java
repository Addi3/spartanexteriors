package dev.isxander.yacl3.gui.tab;

import com.google.common.collect.ImmutableList;
import dev.isxander.yacl3.gui.ElementListWidgetExt;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.ParentElement;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.navigation.GuiNavigation;
import net.minecraft.client.gui.navigation.GuiNavigationPath;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.screen.ScreenTexts;

public class ListHolderWidget<T extends ElementListWidgetExt<?>> extends ClickableWidget implements ParentElement {
    private final Supplier<ScreenRect> dimensions;
    private final T list;

    public ListHolderWidget(Supplier<ScreenRect> dimensions, T list) {
        super(0, 0, 100, 0, ScreenTexts.EMPTY);
        this.dimensions = dimensions;
        this.list = list;
    }

    @Override
    public void renderButton(DrawContext guiGraphics, int mouseX, int mouseY, float deltaTick) {
        ScreenRect dimensions = this.dimensions.get();
        this.method_46421(dimensions.getLeft());
        this.method_46419(dimensions.getTop());
        this.width = dimensions.width();
        this.height = dimensions.height();
        this.list.updateDimensions(dimensions);
        this.list.render(guiGraphics, mouseX, mouseY, deltaTick);
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder output) {
        this.list.appendNarrations(output);
    }

    @Override
    public List<? extends Element> children() {
        return ImmutableList.of(this.list);
    }

    public T getList() {
        return list;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return this.list.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        return this.list.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        return this.list.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, /*? if >1.20.2 {*/ /*double horizontal, *//*?}*/ double vertical) {
        return this.list.mouseScrolled(mouseX, mouseY, /*? if >1.20.2 {*/ /*horizontal, *//*?}*/ vertical);
    }

    @Override
    public boolean keyPressed(int i, int j, int k) {
        return this.list.keyPressed(i, j, k);
    }

    @Override
    public boolean charTyped(char c, int i) {
        return this.list.charTyped(c, i);
    }

    @Override
    public boolean isDragging() {
        return this.list.isDragging();
    }

    @Override
    public void setDragging(boolean dragging) {
        this.list.setDragging(dragging);
    }

    @Nullable
    @Override
    public Element getFocused() {
        return this.list.getFocused();
    }

    @Override
    public void setFocused(@Nullable Element listener) {
        this.list.setFocused(listener);
    }

    @Nullable
    @Override
    public GuiNavigationPath getNavigationPath(GuiNavigation event) {
        return this.list.getNavigationPath(event);
    }

    @Nullable
    @Override
    public GuiNavigationPath getFocusedPath() {
        return this.list.getFocusedPath();
    }
}
