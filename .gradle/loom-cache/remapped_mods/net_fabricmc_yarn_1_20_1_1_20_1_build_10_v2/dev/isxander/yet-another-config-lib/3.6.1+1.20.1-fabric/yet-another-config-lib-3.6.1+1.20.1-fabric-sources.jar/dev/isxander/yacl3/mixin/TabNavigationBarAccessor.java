package dev.isxander.yacl3.mixin;

import com.google.common.collect.ImmutableList;
import net.minecraft.client.gui.tab.Tab;
import net.minecraft.client.gui.tab.TabManager;
import net.minecraft.client.gui.widget.TabButtonWidget;
import net.minecraft.client.gui.widget.TabNavigationWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(TabNavigationWidget.class)
public interface TabNavigationBarAccessor {
    /*? if >1.20.4 {*/
    /*@Accessor("layout")
    net.minecraft.client.gui.layouts.LinearLayout yacl$getLayout();
    *//*?} else {*/
    @Accessor("layout")
    net.minecraft.client.gui.widget.GridWidget yacl$getLayout();
    /*?}*/

    @Accessor("width")
    int yacl$getWidth();

    @Accessor("tabManager")
    TabManager yacl$getTabManager();

    @Accessor("tabs")
    ImmutableList<Tab> yacl$getTabs();

    @Accessor("tabButtons")
    ImmutableList<TabButtonWidget> yacl$getTabButtons();

}
