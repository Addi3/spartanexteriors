package dev.isxander.yacl3.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.isxander.yacl3.api.*;
import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.api.utils.MutableDimension;
import dev.isxander.yacl3.api.utils.OptionUtils;
import dev.isxander.yacl3.gui.controllers.PopupControllerScreen;
import dev.isxander.yacl3.gui.controllers.ControllerPopupWidget;
import dev.isxander.yacl3.gui.tab.ListHolderWidget;
import dev.isxander.yacl3.gui.tab.ScrollableNavigationBar;
import dev.isxander.yacl3.gui.tab.TabExt;
import dev.isxander.yacl3.gui.utils.GuiUtils;
import dev.isxander.yacl3.impl.utils.YACLConstants;
import dev.isxander.yacl3.platform.YACLPlatform;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.MultilineText;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tab.TabManager;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.tooltip.TooltipBackgroundRenderer;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.util.InputUtil;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class YACLScreen extends Screen {
    public final YetAnotherConfigLib config;

    private final Screen parent;

    public final TabManager tabManager = new TabManager(this::addDrawableChild, this::remove);
    public ScrollableNavigationBar tabNavigationBar;
    public ScreenRect tabArea;

    public Text saveButtonMessage;
    public Tooltip saveButtonTooltipMessage;
    private int saveButtonMessageTime;

    private boolean pendingChanges;

    public ControllerPopupWidget<?> currentPopupController = null;
    public boolean popupControllerVisible = false;

    public YACLScreen(YetAnotherConfigLib config, Screen parent) {
        super(config.title());
        this.config = config;
        this.parent = parent;

        OptionUtils.forEachOptions(config, option -> {
            option.addListener((opt, val) -> onOptionChanged(opt));
        });
    }

    @Override
    protected void init() {
        tabArea = new ScreenRect(0, 24 - 1, this.width, this.height - 24 + 1);

        int currentTab = tabNavigationBar != null
                ? tabNavigationBar.getTabs().indexOf(tabManager.getCurrentTab())
                : 0;
        if (currentTab == -1)
            currentTab = 0;

        tabNavigationBar = new ScrollableNavigationBar(this.width, tabManager, config.categories()
                .stream()
                .map(category -> {
                    if (category instanceof CustomTabProvider tabProvider) {
                        return tabProvider.createTab(this, tabArea);
                    }
                    if (category instanceof PlaceholderCategory placeholder)
                        return new PlaceholderTab(placeholder, this);
                    return new CategoryTab(this, category, tabArea);
                }).toList());
        tabNavigationBar.selectTab(currentTab, false);
        tabNavigationBar.init();
        tabManager.setTabArea(tabArea);
        addDrawableChild(tabNavigationBar);

        config.initConsumer().accept(this);
    }

    public void addPopupControllerWidget(ControllerPopupWidget<?> controllerPopupWidget) {

        //Safety check for the color picker
        if (currentPopupController != null) {
            clearPopupControllerWidget();
        }

        currentPopupController = controllerPopupWidget;
        popupControllerVisible = true;

        OptionListWidget optionListWidget = null;
        if(this.tabNavigationBar.getTabManager().getCurrentTab() instanceof CategoryTab categoryTab) {
            optionListWidget = categoryTab.optionList.getList();
        }
        if(optionListWidget != null) {
            this.client.setScreen(new PopupControllerScreen(this, controllerPopupWidget));
        }
    }

    public void clearPopupControllerWidget() {
        if(MinecraftClient.getInstance().currentScreen instanceof PopupControllerScreen popupControllerScreen) {
            popupControllerScreen.close();
        }
        popupControllerVisible = false;
        currentPopupController = null;
    }

    /*? if <=1.20.4 {*/
    @Override
    public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
        renderBackgroundTexture(graphics);
        super.render(graphics, mouseX, mouseY, delta);
    }
    /*?}*/

    @Override
    public void renderBackground(DrawContext guiGraphics/*? if >1.20.1 {*//*, int mouseX, int mouseY, float partialTick*//*?}*/) {
        super.renderBackground(guiGraphics/*? if >1.20.1 {*//*, mouseX, mouseY, partialTick*//*?}*/);

        if (tabManager.getCurrentTab() instanceof TabExt tab) {
            tab.renderBackground(guiGraphics);
        }
    }

    public void finishOrSave() {
        saveButtonMessage = null;

        if (pendingChanges()) {
            Set<OptionFlag> flags = new HashSet<>();
            OptionUtils.forEachOptions(config, option -> {
                if (option.applyValue()) {
                    flags.addAll(option.flags());
                }
            });
            OptionUtils.forEachOptions(config, option -> {
                if (option.changed()) {
                    // if still changed after applying, reset to the current value from binding
                    // as something has gone wrong.
                    option.forgetPendingValue();
                    YACLConstants.LOGGER.error("Option '{}' value mismatch after applying! Reset to binding's getter.", option.name().getString());
                }
            });
            config.saveFunction().run();

            flags.forEach(flag -> flag.accept(client));

            pendingChanges = false;
            if (tabManager.getCurrentTab() instanceof CategoryTab categoryTab) {
                categoryTab.updateButtons();
            }
        } else close();
    }

    public void cancelOrReset() {
        if (pendingChanges()) { // if pending changes, button acts as a cancel button
            OptionUtils.forEachOptions(config, Option::forgetPendingValue);
            close();
        } else { // if not, button acts as a reset button
            OptionUtils.forEachOptions(config, Option::requestSetDefault);
        }
    }

    public void undo() {
        OptionUtils.forEachOptions(config, Option::forgetPendingValue);
    }

    @Override
    public void tick() {
        if (tabManager.getCurrentTab() instanceof TabExt tabExt) {
            tabExt.tick();
        }

        if (tabManager.getCurrentTab() instanceof CategoryTab categoryTab) {
            if (saveButtonMessage != null) {
                if (saveButtonMessageTime > 140) {
                    saveButtonMessage = null;
                    saveButtonTooltipMessage = null;
                    saveButtonMessageTime = 0;
                } else {
                    saveButtonMessageTime++;
                    categoryTab.saveFinishedButton.setMessage(saveButtonMessage);
                    if (saveButtonTooltipMessage != null) {
                        categoryTab.saveFinishedButton.setTooltip(saveButtonTooltipMessage);
                    }
                }
            }
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) {
            this.setDragging(true);
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        return this.getFocused() != null
                && this.isDragging()
                && (button == InputUtil.field_32000 || button == InputUtil.field_32002)
                && this.getFocused().mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    public void setSaveButtonMessage(Text message, Text tooltip) {
        saveButtonMessage = message;
        saveButtonTooltipMessage = Tooltip.of(tooltip);
        saveButtonMessageTime = 0;
    }

    public boolean pendingChanges() {
        return pendingChanges;
    }

    private void onOptionChanged(Option<?> option) {
        pendingChanges = false;

        OptionUtils.consumeOptions(config, opt -> {
            pendingChanges |= opt.changed();
            return pendingChanges;
        });

        if (tabManager.getCurrentTab() instanceof CategoryTab categoryTab) {
            categoryTab.updateButtons();
        }
    }

    @Override
    public boolean shouldCloseOnEsc() {
        if (pendingChanges()) {
            setSaveButtonMessage(Text.translatable("yacl.gui.save_before_exit").formatted(Formatting.RED), Text.translatable("yacl.gui.save_before_exit.tooltip"));
            return false;
        }
        return true;
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }

    public static void renderMultilineTooltip(DrawContext graphics, TextRenderer font, MultilineText text, int centerX, int yAbove, int yBelow, int screenWidth, int screenHeight) {
        if (text.count() > 0) {
            int maxWidth = text.getMaxWidth();
            int lineHeight = font.fontHeight + 1;
            int height = text.count() * lineHeight - 1;

            int belowY = yBelow + 12;
            int aboveY = yAbove - height + 12;
            int maxBelow = screenHeight - (belowY + height);
            int minAbove = aboveY - height;
            int y = aboveY;
            if (minAbove < 8)
                y = maxBelow > minAbove ? belowY : aboveY;

            int x = Math.max(centerX - text.getMaxWidth() / 2 - 12, -6);

            int drawX = x + 12;
            int drawY = y - 12;

            graphics.getMatrices().push();
            TooltipBackgroundRenderer.render(
                    graphics,
                    drawX,
                    drawY,
                    maxWidth,
                    height,
                    400/*? if >=1.21.2 {*//*,
                    null*//*?}*/
            );
            graphics.getMatrices().translate(0.0, 0.0, 400.0);

            text.drawWithShadow(graphics, drawX, drawY, lineHeight, -1);

            graphics.getMatrices().pop();
        }
    }

    public static class CategoryTab implements TabExt {
        /*? if >1.20.4 {*/
        /*private static final ResourceLocation DARKER_BG = YACLPlatform.mcRl("textures/gui/menu_list_background.png");
        *//*?}*/

        private final YACLScreen screen;
        private final ConfigCategory category;
        private final Tooltip tooltip;

        private ListHolderWidget<OptionListWidget> optionList;
        public final ButtonWidget saveFinishedButton;
        public final ButtonWidget cancelResetButton;
        public final ButtonWidget undoButton;
        private final SearchFieldWidget searchField;
        private OptionDescriptionWidget descriptionWidget;

        private final ScreenRect rightPaneDim;

        public CategoryTab(YACLScreen screen, ConfigCategory category, ScreenRect tabArea) {
            this.screen = screen;
            this.category = category;
            this.tooltip = Tooltip.of(category.tooltip());

            int columnWidth = screen.width / 3;
            int padding = columnWidth / 20;
            columnWidth = Math.min(columnWidth, 400);
            int paddedWidth = columnWidth - padding * 2;
            rightPaneDim = new ScreenRect(screen.width / 3 * 2, tabArea.getTop() + 1, screen.width / 3, tabArea.height());
            MutableDimension<Integer> actionDim = Dimension.ofInt(screen.width / 3 * 2 + screen.width / 6, screen.height - padding - 20, paddedWidth, 20);

            saveFinishedButton = ButtonWidget.builder(Text.literal("Done"), btn -> screen.finishOrSave())
                    .position(actionDim.x() - actionDim.width() / 2, actionDim.y())
                    .size(actionDim.width(), actionDim.height())
                    .build();

            actionDim.expand(-actionDim.width() / 2 - 2, 0).move(-actionDim.width() / 2 - 2, -22);
            cancelResetButton = ButtonWidget.builder(Text.literal("Cancel"), btn -> screen.cancelOrReset())
                    .position(actionDim.x() - actionDim.width() / 2, actionDim.y())
                    .size(actionDim.width(), actionDim.height())
                    .build();

            actionDim.move(actionDim.width() + 4, 0);
            undoButton = ButtonWidget.builder(Text.translatable("yacl.gui.undo"), btn -> screen.undo())
                    .position(actionDim.x() - actionDim.width() / 2, actionDim.y())
                    .size(actionDim.width(), actionDim.height())
                    .tooltip(Tooltip.of(Text.translatable("yacl.gui.undo.tooltip")))
                    .build();

            searchField = new SearchFieldWidget(
                    screen,
                    screen.textRenderer,
                    screen.width / 3 * 2 + screen.width / 6 - paddedWidth / 2 + 1,
                    undoButton.getY() - 22,
                    paddedWidth - 2, 18,
                    Text.translatable("gui.recipebook.search_hint"),
                    Text.translatable("gui.recipebook.search_hint"),
                    searchQuery -> optionList.getList().updateSearchQuery(searchQuery)
            );

            this.optionList = new ListHolderWidget<>(
                    () -> new ScreenRect(tabArea.position(), tabArea.width() / 3 * 2, tabArea.height()),
                    new OptionListWidget(screen, category, screen.client, 0, 0, screen.width / 3 * 2 + 1, screen.height, desc -> {
                        descriptionWidget.setOptionDescription(desc);
                    })
            );

            descriptionWidget = new OptionDescriptionWidget(
                    () -> new ScreenRect(
                            screen.width / 3 * 2 + padding,
                            tabArea.getTop() + padding,
                            paddedWidth,
                            searchField.getY() - 1 - tabArea.getTop() - padding * 2
                    ),
                    null
            );

            updateButtons();
        }

        @Override
        public Text getTitle() {
            return category.name();
        }

        @Override
        public void forEachChild(Consumer<ClickableWidget> consumer) {
            consumer.accept(optionList);
            consumer.accept(saveFinishedButton);
            consumer.accept(cancelResetButton);
            consumer.accept(undoButton);
            consumer.accept(searchField);
            consumer.accept(descriptionWidget);
        }

        /*? if >1.20.4 {*/
        /*@Override
        public void renderBackground(GuiGraphics graphics) {
            RenderSystem.enableBlend();
            // right pane darker db
            GuiUtils.blitGuiTex(graphics, DARKER_BG, rightPaneDim.left(), rightPaneDim.top(), rightPaneDim.right() + 2, rightPaneDim.bottom() + 2, rightPaneDim.width() + 2, rightPaneDim.height() + 2, 32, 32);
            
            // top separator for right pane
            graphics.pose().pushPose();
            graphics.pose().translate(0, 0, 10);
            GuiUtils.blitGuiTex(graphics, CreateWorldScreen.HEADER_SEPARATOR, rightPaneDim.left() - 1, rightPaneDim.top() - 2, 0.0F, 0.0F, rightPaneDim.width() + 1, 2, 32, 2);
            graphics.pose().popPose();

            // left separator for right pane
            graphics.pose().pushPose();
            graphics.pose().translate(rightPaneDim.left(), rightPaneDim.top() - 1, 0);
            graphics.pose().rotateAround(Axis.ZP.rotationDegrees(90), 0, 0, 1);
            GuiUtils.blitGuiTex(graphics, CreateWorldScreen.FOOTER_SEPARATOR, 0, 0, 0f, 0f, rightPaneDim.height() + 1, 2, 32, 2);
            graphics.pose().popPose();

            RenderSystem.disableBlend();
        }
        *//*?}*/

        @Override
        public void refreshGrid(ScreenRect screenRectangle) {

        }

        @Override
        public void tick() {
            descriptionWidget.tick();
        }

        @Nullable
        @Override
        public Tooltip getTooltip() {
            return tooltip;
        }

        public void updateButtons() {
            boolean pendingChanges = screen.pendingChanges();

            undoButton.active = pendingChanges;
            saveFinishedButton.setMessage(pendingChanges ? Text.translatable("yacl.gui.save") : GuiUtils.translatableFallback("yacl.gui.done", ScreenTexts.DONE));
            saveFinishedButton.setTooltip(new YACLTooltip(pendingChanges ? Text.translatable("yacl.gui.save.tooltip") : Text.translatable("yacl.gui.finished.tooltip"), saveFinishedButton));
            cancelResetButton.setMessage(pendingChanges ? GuiUtils.translatableFallback("yacl.gui.cancel", ScreenTexts.CANCEL) : Text.translatable("controls.reset"));
            cancelResetButton.setTooltip(new YACLTooltip(pendingChanges ? Text.translatable("yacl.gui.cancel.tooltip") : Text.translatable("yacl.gui.reset.tooltip"), cancelResetButton));
        }
    }

    public static class PlaceholderTab implements TabExt {
        private final YACLScreen screen;
        private final PlaceholderCategory category;
        private final Tooltip tooltip;

        public PlaceholderTab(PlaceholderCategory category, YACLScreen screen) {
            this.screen = screen;
            this.category = category;
            this.tooltip = Tooltip.of(category.tooltip());
        }

        @Override
        public Text getTitle() {
            return category.name();
        }

        @Override
        public void forEachChild(Consumer<ClickableWidget> consumer) {

        }

        @Override
        public void refreshGrid(ScreenRect screenRectangle) {
            screen.client.setScreen(category.screen().apply(screen.client, screen));
        }

        @Override
        public @Nullable Tooltip getTooltip() {
            return this.tooltip;
        }
    }
}
