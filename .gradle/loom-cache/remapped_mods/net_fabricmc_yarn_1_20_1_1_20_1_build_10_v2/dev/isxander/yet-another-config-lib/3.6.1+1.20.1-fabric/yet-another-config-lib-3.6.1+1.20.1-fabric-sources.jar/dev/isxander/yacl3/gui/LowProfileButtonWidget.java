package dev.isxander.yacl3.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class LowProfileButtonWidget extends ButtonWidget {
    public LowProfileButtonWidget(int x, int y, int width, int height, Text message, PressAction onPress) {
        super(x, y, width, height, message, onPress, DEFAULT_NARRATION_SUPPLIER);
    }

    public LowProfileButtonWidget(int x, int y, int width, int height, Text message, PressAction onPress, Tooltip tooltip) {
        this(x, y, width, height, message, onPress);
        setTooltip(tooltip);
    }

    @Override
    public void renderButton(DrawContext graphics, int mouseX, int mouseY, float deltaTicks) {
        if (!isSelected() || !active) {
            int j = this.active ? 0xFFFFFF : 0xA0A0A0;
            this.drawMessage(graphics, MinecraftClient.getInstance().textRenderer, j);
        } else {
            super.renderButton(graphics, mouseX, mouseY, deltaTicks);
        }
    }
}
