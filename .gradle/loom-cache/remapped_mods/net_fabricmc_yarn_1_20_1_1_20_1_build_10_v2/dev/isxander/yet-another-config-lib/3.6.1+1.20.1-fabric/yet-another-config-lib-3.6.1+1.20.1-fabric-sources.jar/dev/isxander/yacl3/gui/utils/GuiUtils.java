package dev.isxander.yacl3.gui.utils;

import java.util.function.Consumer;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Language;

public class GuiUtils {
    public static void drawSpecial(DrawContext graphics, Consumer<VertexConsumerProvider> consumer) {
        //? if >=1.21.2 {
        /*graphics.drawSpecial(consumer);
        *///?} else {
        VertexConsumerProvider.Immediate bufferSource = graphics.getVertexConsumers();
        consumer.accept(bufferSource);
        bufferSource.draw();
        //?}
    }

    public static void blitGuiTex(DrawContext graphics, Identifier texture, int x, int y, float u, float v, int textureWidth, int textureHeight, int width, int height) {
        graphics.drawTexture(
                //? if >=1.21.2
                /*RenderType::guiTextured,*/
                texture,
                x, y,
                u, v,
                textureWidth, textureHeight,
                width, height
        );
    }

    public static void blitGuiTexColor(DrawContext graphics, Identifier texture, int x, int y, float u, float v, int textureWidth, int textureHeight, int width, int height, int color) {
        //? if <1.21.2 {
        float a = (color >> 24 & 255) / 255.0F;
        float r = (color >> 16 & 255) / 255.0F;
        float g = (color >> 8 & 255) / 255.0F;
        float b = (color & 255) / 255.0F;
        graphics.setShaderColor(r, g, b, a);
        //?}
        graphics.drawTexture(
                //? if >=1.21.2
                /*RenderType::guiTextured,*/
                texture,
                x, y,
                u, v,
                textureWidth, textureHeight,
                width, height
                //? if >=1.21.2
                /*,color*/
        );
        //? if <1.21.2
        graphics.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    //? if >1.20.1 {
    /*public static void blitSprite(GuiGraphics graphics, ResourceLocation sprite, int x, int y, int width, int height) {
        graphics.blitSprite(
                //? if >=1.21.2
                RenderType::guiTextured,
                sprite,
                x, y,
                width, height
        );
    }
    *///?}

    public static MutableText translatableFallback(String key, Text fallback) {
        if (Language.getInstance().hasTranslation(key))
            return Text.translatable(key);
        return fallback.copy();
    }

    public static String shortenString(String string, TextRenderer font, int maxWidth, String suffix) {
        if (string.isEmpty())
            return string;

        boolean firstIter = true;
        while (font.getWidth(string) > maxWidth) {
            string = string.substring(0, Math.max(string.length() - 1 - (firstIter ? 1 : suffix.length() + 1), 0)).trim();
            string += suffix;

            if (string.equals(suffix))
                break;

            firstIter = false;
        }

        return string;
    }


    public static void setPixelARGB(NativeImage nativeImage, int x, int y, int argb) {
        // In 1.21.2+, you set the pixel color in ARGB format, where it internally converts to ABGR.
        // Before this, you need to directly set the pixel color in ABGR format.

        //? if >=1.21.2 {
        /*nativeImage.setPixel(x, y, argb);
        *///?} else {
        int a = (argb >> 24) & 0xFF;
        int r = (argb >> 16) & 0xFF;
        int g = (argb >> 8) & 0xFF;
        int b = argb & 0xFF;
        int abgr = (a << 24) | (b << 16) | (g << 8) | r;
        nativeImage.setColor(x, y, abgr); // method name is misleading. It's actually ABGR.
        //?}
    }
}
