package dev.isxander.yacl3.gui.tab;

import com.google.common.collect.ImmutableList;
import dev.isxander.yacl3.mixin.TabNavigationBarAccessor;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.tab.Tab;
import net.minecraft.client.gui.tab.TabManager;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.LayoutWidget;
import net.minecraft.client.gui.widget.TabButtonWidget;
import net.minecraft.client.gui.widget.TabNavigationWidget;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.Nullable;

public class ScrollableNavigationBar extends TabNavigationWidget {
    private static final int NAVBAR_MARGIN = 28;

    private static final TextRenderer font = MinecraftClient.getInstance().textRenderer;

    private int scrollOffset;
    private int maxScrollOffset;

    private final TabNavigationBarAccessor accessor;

    public ScrollableNavigationBar(int width, TabManager tabManager, Iterable<? extends Tab> tabs) {
        super(width, tabManager, ImmutableList.copyOf(tabs));
        this.accessor = (TabNavigationBarAccessor) this;

        // add tab tooltips to the tab buttons
        for (TabButtonWidget tabButton : accessor.yacl$getTabButtons()) {
            if (tabButton.getTab() instanceof TabExt tab) {
                tabButton.setTooltip(tab.getTooltip());
            }
        }
    }

    @Override
    public void init() {
        ImmutableList<TabButtonWidget> tabButtons = accessor.yacl$getTabButtons();
        int noScrollWidth = accessor.yacl$getWidth() - NAVBAR_MARGIN*2;

        int allTabsWidth = 0;
        // first pass: set the width of each tab button
        for (TabButtonWidget tabButton : tabButtons) {
            int buttonWidth = font.getWidth(tabButton.getMessage()) + 20;
            allTabsWidth += buttonWidth;
            tabButton.setWidth(buttonWidth);
        }

        if (allTabsWidth < noScrollWidth) {
            int equalWidth = noScrollWidth / tabButtons.size();
            var smallTabs = tabButtons.stream().filter(btn -> btn.getWidth() < equalWidth).toList();
            var bigTabs = tabButtons.stream().filter(btn -> btn.getWidth() >= equalWidth).toList();
            int leftoverWidth = noScrollWidth - bigTabs.stream().mapToInt(ClickableWidget::getWidth).sum();
            int equalWidthForSmallTabs = leftoverWidth / smallTabs.size();
            for (TabButtonWidget tabButton : smallTabs) {
                tabButton.setWidth(equalWidthForSmallTabs);
            }

            allTabsWidth = noScrollWidth;
        }

        LayoutWidget layout = ((TabNavigationBarAccessor) this).yacl$getLayout();
        layout.refreshPositions();
        layout.setY(0);
        scrollOffset = 0;

        layout.setX(Math.max((accessor.yacl$getWidth() - allTabsWidth) / 2, NAVBAR_MARGIN));
        this.maxScrollOffset = Math.max(0, allTabsWidth - noScrollWidth);
    }

    @Override
    public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
        graphics.getMatrices().push();
        // render option list BELOW the navbar without need to scissor
        graphics.getMatrices().translate(0, 0, 10);

        super.render(graphics, mouseX, mouseY, delta);

        graphics.getMatrices().pop();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, /*? if >1.20.2 {*/ /*double horizontal, *//*?}*/ double vertical) {
        this.setScrollOffset(this.scrollOffset - (int)(vertical*15));
        return true;
    }

    @Override
    public boolean isMouseOver(double mouseX, double mouseY) {
        return mouseY <= 24;
    }

    public void setScrollOffset(int scrollOffset) {
        LayoutWidget layout = ((TabNavigationBarAccessor) this).yacl$getLayout();

        layout.setX(layout.getX() + this.scrollOffset);
        this.scrollOffset = MathHelper.clamp(scrollOffset, 0, maxScrollOffset);
        layout.setX(layout.getX() - this.scrollOffset);
    }

    public int getScrollOffset() {
        return scrollOffset;
    }

    @Override
    public void setFocused(@Nullable Element child) {
        super.setFocused(child);
        if (child instanceof TabButtonWidget tabButton) {
            this.ensureVisible(tabButton);
        }
    }

    protected void ensureVisible(TabButtonWidget tabButton) {
        if (tabButton.getX() < NAVBAR_MARGIN) {
            this.setScrollOffset(this.scrollOffset - (NAVBAR_MARGIN - tabButton.getX()));
        } else if (tabButton.getX() + tabButton.getWidth() > accessor.yacl$getWidth() - NAVBAR_MARGIN) {
            this.setScrollOffset(this.scrollOffset + (tabButton.getX() + tabButton.getWidth() - (accessor.yacl$getWidth() - NAVBAR_MARGIN)));
        }
    }

    public ImmutableList<Tab> getTabs() {
        return accessor.yacl$getTabs();
    }

    public TabManager getTabManager() {
        return accessor.yacl$getTabManager();
    }
}
