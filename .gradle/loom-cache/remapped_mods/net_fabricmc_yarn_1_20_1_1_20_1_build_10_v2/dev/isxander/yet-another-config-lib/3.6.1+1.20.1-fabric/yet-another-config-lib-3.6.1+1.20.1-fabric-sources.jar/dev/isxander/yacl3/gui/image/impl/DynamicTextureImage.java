package dev.isxander.yacl3.gui.image.impl;

import com.mojang.blaze3d.platform.GlConst;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.isxander.yacl3.debug.DebugProperties;
import dev.isxander.yacl3.gui.image.ImageRenderer;
import dev.isxander.yacl3.gui.image.ImageRendererFactory;
import dev.isxander.yacl3.gui.utils.GuiUtils;
import java.io.FileInputStream;
import java.nio.file.Path;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.util.Identifier;

public class DynamicTextureImage implements ImageRenderer {
    protected static final TextureManager textureManager = MinecraftClient.getInstance().getTextureManager();

    protected NativeImage image;
    protected NativeImageBackedTexture texture;
    protected final Identifier uniqueLocation;
    protected final int width, height;

    public DynamicTextureImage(NativeImage image, Identifier location) {
        RenderSystem.assertOnRenderThread();

        this.image = image;
        this.texture = new NativeImageBackedTexture(image);
        this.uniqueLocation = location;
        textureManager.registerTexture(this.uniqueLocation, this.texture);
        this.width = image.getWidth();
        this.height = image.getHeight();
    }

    @Override
    public int render(DrawContext graphics, int x, int y, int renderWidth, float tickDelta) {
        if (image == null) return 0;

        float ratio = renderWidth / (float)this.width;
        int targetHeight = (int) (this.height * ratio);

        graphics.getMatrices().push();
        graphics.getMatrices().translate(x, y, 0);
        graphics.getMatrices().scale(ratio, ratio, 1);

        if (DebugProperties.IMAGE_FILTERING) {
            GlStateManager._texParameter(GlConst.GL_TEXTURE_2D, GlConst.GL_TEXTURE_MAG_FILTER, GlConst.GL_LINEAR);
            GlStateManager._texParameter(GlConst.GL_TEXTURE_2D, GlConst.GL_TEXTURE_MIN_FILTER, GlConst.GL_LINEAR);
        }

        GuiUtils.blitGuiTex(graphics, uniqueLocation, 0, 0, 0, 0, this.width, this.height, this.width, this.height);

        graphics.getMatrices().pop();

        return targetHeight;
    }

    @Override
    public void close() {
        image.close();
        image = null;
        texture = null;
        textureManager.destroyTexture(uniqueLocation);
    }

    public static ImageRendererFactory fromPath(Path imagePath, Identifier location) {
        return (ImageRendererFactory.OnThread) () -> () -> new DynamicTextureImage(NativeImage.read(new FileInputStream(imagePath.toFile())), location);
    }
}
