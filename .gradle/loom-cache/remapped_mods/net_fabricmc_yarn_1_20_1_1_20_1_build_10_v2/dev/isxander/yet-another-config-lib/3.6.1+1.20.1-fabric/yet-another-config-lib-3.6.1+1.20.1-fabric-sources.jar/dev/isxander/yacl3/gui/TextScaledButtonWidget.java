package dev.isxander.yacl3.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

public class TextScaledButtonWidget extends TooltipButtonWidget {
    public float textScale;

    public TextScaledButtonWidget(Screen screen, int x, int y, int width, int height, float textScale, Text message, Text tooltip, PressAction onPress) {
        super(screen, x, y, width, height, message, tooltip, onPress);
        this.textScale = textScale;
    }

    public TextScaledButtonWidget(Screen screen, int x, int y, int width, int height, float textScale, Text message, PressAction onPress) {
        this(screen, x, y, width, height, textScale, message, null, onPress);
    }

    @Override
    public void drawMessage(DrawContext graphics, TextRenderer textRenderer, int color) {
        TextRenderer font = MinecraftClient.getInstance().textRenderer;
        MatrixStack pose = graphics.getMatrices();

        pose.push();
        pose.translate(((this.getX() + this.width / 2f) - font.getWidth(getMessage()) * textScale / 2), (float)this.getY() + (this.height - 8 * textScale) / 2f / textScale, 0);
        pose.scale(textScale, textScale, 1);
        graphics.drawText(font, getMessage(), 0, 0, color | MathHelper.ceil(this.alpha * 255.0F) << 24, true);
        pose.pop();
    }
}
