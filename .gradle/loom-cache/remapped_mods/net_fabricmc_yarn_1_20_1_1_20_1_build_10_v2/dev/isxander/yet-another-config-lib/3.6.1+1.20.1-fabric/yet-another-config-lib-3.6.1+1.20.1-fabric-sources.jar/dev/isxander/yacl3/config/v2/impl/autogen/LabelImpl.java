package dev.isxander.yacl3.config.v2.impl.autogen;

import dev.isxander.yacl3.api.LabelOption;
import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.config.v2.api.ConfigField;
import dev.isxander.yacl3.config.v2.api.autogen.OptionFactory;
import net.minecraft.text.Text;
import dev.isxander.yacl3.config.v2.api.autogen.Label;
import dev.isxander.yacl3.config.v2.api.autogen.OptionAccess;

public class LabelImpl implements OptionFactory<Label, Text> {
    @Override
    public Option<Text> createOption(Label annotation, ConfigField<Text> field, OptionAccess optionAccess) {
        return LabelOption.create(field.access().get());
    }
}
