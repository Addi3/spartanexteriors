package dev.isxander.yacl3.gui;

import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.text.Text;

public class YACLTooltip extends Tooltip {
    private final net.minecraft.client.gui.widget.ClickableWidget widget;

    public YACLTooltip(Text tooltip, net.minecraft.client.gui.widget.ClickableWidget widget) {
        super(tooltip, tooltip);
        this.widget = widget;
    }

    //? if >1.20.1 && <=1.20.4 {
    /*@Override
    protected ClientTooltipPositioner createTooltipPositioner(boolean bl, boolean bl2, ScreenRectangle screenRectangle) {
        return new YACLTooltipPositioner(widget);
    }
    *///?}
}
