/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.object.builder.v1.block;

import java.util.function.Function;
import java.util.function.ToIntFunction;
import net.fabricmc.fabric.mixin.object.builder.AbstractBlockAccessor;
import net.fabricmc.fabric.mixin.object.builder.AbstractBlockSettingsAccessor;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.MapColor;
import net.minecraft.block.enums.Instrument;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.entity.EntityType;
import net.minecraft.resource.featuretoggle.FeatureFlag;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Identifier;

/**
 * Fabric's version of Block.Settings. Adds additional methods and hooks
 * not found in the original class.
 *
 * <p>Make note that this behaves slightly different from the
 * vanilla counterpart, copying some settings that vanilla does not.
 *
 * <p>To use it, simply replace Block.Settings.of() with
 * FabricBlockSettings.of().
 */
public class FabricBlockSettings extends AbstractBlock.Settings {
	protected FabricBlockSettings() {
		super();
	}

	protected FabricBlockSettings(AbstractBlock.Settings settings) {
		this();
		// Mostly Copied from vanilla's copy method
		// Note: If new methods are added to Block settings, an accessor must be added here
		AbstractBlockSettingsAccessor thisAccessor = (AbstractBlockSettingsAccessor) this;
		AbstractBlockSettingsAccessor otherAccessor = (AbstractBlockSettingsAccessor) settings;

		// Copied in vanilla: sorted by vanilla copy order
		this.method_36557(otherAccessor.getHardness());
		this.method_36558(otherAccessor.getResistance());
		this.collidable(otherAccessor.getCollidable());
		thisAccessor.setRandomTicks(otherAccessor.getRandomTicks());
		this.method_9631(otherAccessor.getLuminance());
		thisAccessor.setMapColorProvider(otherAccessor.getMapColorProvider());
		this.method_9626(otherAccessor.getSoundGroup());
		this.method_9628(otherAccessor.getSlipperiness());
		this.method_23351(otherAccessor.getVelocityMultiplier());
		thisAccessor.setDynamicBounds(otherAccessor.getDynamicBounds());
		thisAccessor.setOpaque(otherAccessor.getOpaque());
		thisAccessor.setIsAir(otherAccessor.getIsAir());
		thisAccessor.setBurnable(otherAccessor.getBurnable());
		thisAccessor.setLiquid(otherAccessor.getLiquid());
		thisAccessor.setForceNotSolid(otherAccessor.getForceNotSolid());
		thisAccessor.setForceSolid(otherAccessor.getForceSolid());
		this.method_50012(otherAccessor.getPistonBehavior());
		thisAccessor.setToolRequired(otherAccessor.isToolRequired());
		thisAccessor.setOffsetter(otherAccessor.getOffsetter());
		thisAccessor.setBlockBreakParticles(otherAccessor.getBlockBreakParticles());
		thisAccessor.setRequiredFeatures(otherAccessor.getRequiredFeatures());
		this.method_26249(otherAccessor.getEmissiveLightingPredicate());
		this.method_51368(otherAccessor.getInstrument());
		thisAccessor.setReplaceable(otherAccessor.getReplaceable());

		// Not copied in vanilla: field definition order
		this.method_23352(otherAccessor.getJumpVelocityMultiplier());
		this.drops(otherAccessor.getLootTableId());
		this.method_26235(otherAccessor.getAllowsSpawningPredicate());
		this.method_26236(otherAccessor.getSolidBlockPredicate());
		this.method_26243(otherAccessor.getSuffocationPredicate());
		this.method_26245(otherAccessor.getBlockVisionPredicate());
		this.method_26247(otherAccessor.getPostProcessPredicate());
	}

	public static FabricBlockSettings method_9637() {
		return new FabricBlockSettings();
	}

	/**
	 * @deprecated Use {@link FabricBlockSettings#method_9637()} instead.
	 */
	@Deprecated
	public static FabricBlockSettings of() {
		return method_9637();
	}

	public static FabricBlockSettings copyOf(AbstractBlock block) {
		return new FabricBlockSettings(((AbstractBlockAccessor) block).getSettings());
	}

	public static FabricBlockSettings copyOf(AbstractBlock.Settings settings) {
		return new FabricBlockSettings(settings);
	}

	@Override
	public FabricBlockSettings method_9634() {
		super.noCollision();
		return this;
	}

	@Override
	public FabricBlockSettings method_22488() {
		super.nonOpaque();
		return this;
	}

	@Override
	public FabricBlockSettings method_9628(float value) {
		super.slipperiness(value);
		return this;
	}

	@Override
	public FabricBlockSettings method_23351(float velocityMultiplier) {
		super.velocityMultiplier(velocityMultiplier);
		return this;
	}

	@Override
	public FabricBlockSettings method_23352(float jumpVelocityMultiplier) {
		super.jumpVelocityMultiplier(jumpVelocityMultiplier);
		return this;
	}

	@Override
	public FabricBlockSettings method_9626(BlockSoundGroup group) {
		super.sounds(group);
		return this;
	}

	/**
	 * @deprecated Please use {@link FabricBlockSettings#method_9631(ToIntFunction)}.
	 */
	@Deprecated
	public FabricBlockSettings lightLevel(ToIntFunction<BlockState> levelFunction) {
		return this.method_9631(levelFunction);
	}

	@Override
	public FabricBlockSettings method_9631(ToIntFunction<BlockState> luminanceFunction) {
		super.luminance(luminanceFunction);
		return this;
	}

	@Override
	public FabricBlockSettings method_9629(float hardness, float resistance) {
		super.strength(hardness, resistance);
		return this;
	}

	@Override
	public FabricBlockSettings method_9618() {
		super.breakInstantly();
		return this;
	}

	public FabricBlockSettings method_9632(float strength) {
		super.strength(strength);
		return this;
	}

	@Override
	public FabricBlockSettings method_9640() {
		super.ticksRandomly();
		return this;
	}

	@Override
	public FabricBlockSettings method_9624() {
		super.dynamicBounds();
		return this;
	}

	@Override
	public FabricBlockSettings method_42327() {
		super.dropsNothing();
		return this;
	}

	@Override
	public FabricBlockSettings method_16228(Block block) {
		super.dropsLike(block);
		return this;
	}

	@Override
	public FabricBlockSettings method_26250() {
		super.air();
		return this;
	}

	@Override
	public FabricBlockSettings method_26235(AbstractBlock.TypedContextPredicate<EntityType<?>> predicate) {
		super.allowsSpawning(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings method_26236(AbstractBlock.ContextPredicate predicate) {
		super.solidBlock(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings method_26243(AbstractBlock.ContextPredicate predicate) {
		super.suffocates(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings method_26245(AbstractBlock.ContextPredicate predicate) {
		super.blockVision(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings method_26247(AbstractBlock.ContextPredicate predicate) {
		super.postProcess(predicate);
		return this;
	}

	@Override
	public FabricBlockSettings method_26249(AbstractBlock.ContextPredicate predicate) {
		super.emissiveLighting(predicate);
		return this;
	}

	/**
	 * Make the block require tool to drop and slows down mining speed if the incorrect tool is used.
	 */
	@Override
	public FabricBlockSettings method_29292() {
		super.requiresTool();
		return this;
	}

	@Override
	public FabricBlockSettings method_31710(MapColor color) {
		super.mapColor(color);
		return this;
	}

	@Override
	public FabricBlockSettings method_36557(float hardness) {
		super.hardness(hardness);
		return this;
	}

	@Override
	public FabricBlockSettings method_36558(float resistance) {
		super.resistance(resistance);
		return this;
	}

	@Override
	public FabricBlockSettings method_49229(AbstractBlock.OffsetType offsetType) {
		super.offset(offsetType);
		return this;
	}

	@Override
	public FabricBlockSettings method_45477() {
		super.noBlockBreakParticles();
		return this;
	}

	@Override
	public FabricBlockSettings method_45476(FeatureFlag... features) {
		super.requires(features);
		return this;
	}

	@Override
	public FabricBlockSettings method_51520(Function<BlockState, MapColor> mapColorProvider) {
		super.mapColor(mapColorProvider);
		return this;
	}

	@Override
	public FabricBlockSettings method_50013() {
		super.burnable();
		return this;
	}

	@Override
	public FabricBlockSettings method_51177() {
		super.liquid();
		return this;
	}

	@Override
	public FabricBlockSettings method_51369() {
		super.solid();
		return this;
	}

	@Override
	public FabricBlockSettings method_51370() {
		super.notSolid();
		return this;
	}

	@Override
	public FabricBlockSettings method_50012(PistonBehavior pistonBehavior) {
		super.pistonBehavior(pistonBehavior);
		return this;
	}

	@Override
	public FabricBlockSettings method_51368(Instrument instrument) {
		super.instrument(instrument);
		return this;
	}

	@Override
	public FabricBlockSettings method_51371() {
		super.replaceable();
		return this;
	}

	/* FABRIC ADDITIONS*/

	/**
	 * @deprecated Please use {@link FabricBlockSettings#luminance(int)}.
	 */
	@Deprecated
	public FabricBlockSettings lightLevel(int lightLevel) {
		this.luminance(lightLevel);
		return this;
	}

	public FabricBlockSettings luminance(int luminance) {
		this.method_9631(ignored -> luminance);
		return this;
	}

	public FabricBlockSettings drops(Identifier dropTableId) {
		((AbstractBlockSettingsAccessor) this).setLootTableId(dropTableId);
		return this;
	}

	/* FABRIC DELEGATE WRAPPERS */

	/**
	 * @deprecated Please migrate to {@link FabricBlockSettings#method_31710(MapColor)}
	 */
	@Deprecated
	public FabricBlockSettings materialColor(MapColor color) {
		return this.method_31710(color);
	}

	/**
	 * @deprecated Please migrate to {@link FabricBlockSettings#method_51517(DyeColor)}
	 */
	@Deprecated
	public FabricBlockSettings materialColor(DyeColor color) {
		return this.method_51517(color);
	}

	public FabricBlockSettings method_51517(DyeColor color) {
		return this.method_31710(color.getMapColor());
	}

	public FabricBlockSettings collidable(boolean collidable) {
		((AbstractBlockSettingsAccessor) this).setCollidable(collidable);
		return this;
	}
}
