package dev.drtheo.queue.mixin;

import java.util.List;
import net.minecraft.structure.StructureTemplate;
import net.minecraft.util.math.Vec3i;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(StructureTemplate.class)
public interface StructureTemplateAccessor {

    @Accessor("entities")
    List<StructureTemplate.StructureEntityInfo> getEntities();

    @Accessor("size")
    Vec3i getSize();

    @Accessor("blockInfoLists")
    List<StructureTemplate.PalettedBlockInfoList> getBlockInfo();
}